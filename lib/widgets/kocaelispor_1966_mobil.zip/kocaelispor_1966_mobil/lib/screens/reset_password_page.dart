import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ResetPasswordPage extends StatelessWidget {
  final emailController = TextEditingController();
  final auth = FirebaseAuth.instance;

  void resetPassword(BuildContext context) async {
    try {
      await auth.sendPasswordResetEmail(
        email: emailController.text.trim(),
      );
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Şifre sıfırlama e-postası gönderildi.")),
      );
      Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Hata: ${e.toString()}")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Şifre Sıfırlama")),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("E-posta adresinizi girin", style: TextStyle(fontSize: 18)),
            SizedBox(height: 20),
            TextField(
              controller: emailController,
              decoration: InputDecoration(labelText: "E-posta"),
            ),
            SizedBox(height: 24),
            ElevatedButton(
              onPressed: () => resetPassword(context),
              child: Text("Şifre Sıfırlama Linki Gönder"),
            ),
          ],
        ),
      ),
    );
  }
}
